<?php 
define("DB_HOST", "localhost"); //
define("DB_USER", "u0533387_satin"); // u0533387_satin
define("DB_PASS", "!vipSatin"); // !vipSatin
// define("DB_NAME", "u0533387_test");
define("DB_NAME", "u0533387_vipsatin");
define("YML_URL_KINGSILK", "http://kingsilk-opt.ru/YMLexport.xml");
define("MAN_KINGSILK_ID", 18);
define("YML_URL_CLEO", "http://cleo-opt.ru/bitrix/catalog_export/yml_1.php");
// define("IMAGES_PATH", getcwd() . "/www/test.vipsatin.ru/image/"); // end of this constant must be the "/"!!
define("IMAGES_PATH", getcwd() . "/www/vipsatin.ru/image/");
define("IMAGE_PATH_PREFIX", "catalog/Products/"); // end of this constant must be the "/"!!
define("THRESHOLD_SIMILARITY_VALUE", 35); // пороговое значение сходства изображений
define("IMAGICK_METRIC", Imagick::METRIC_PEAKSIGNALTONOISERATIO); // Метрика сравнения изображений
define("UNSORTED_CAT_ID", 321);
define("PRODS_WTH_CAT_NAME_PREFIX_CAT_ID", [59]); // Идентификаторы категорий в наименовании товаров которых, в качестве префикса, должно присутствовать наименование самой категории
 ?>